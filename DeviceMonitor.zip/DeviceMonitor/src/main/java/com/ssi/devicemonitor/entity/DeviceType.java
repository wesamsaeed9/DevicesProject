package com.ssi.devicemonitor.entity;

public enum DeviceType {
    General, Software, Hardware;
}
